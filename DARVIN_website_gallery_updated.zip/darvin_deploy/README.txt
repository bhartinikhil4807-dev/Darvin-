DARVIN WEBSITE — STATIC DEPLOYMENT PACKAGE

Contents:
- index.html
- assets/darvin-hero.jpg (cropped from the supplied homepage design image)
- assets/darvin-tee-hanging.jpg (supplied product photo)
- assets/darvin-model.jpg (supplied model photo)
- assets/darvin-logo-detail.jpg (supplied logo detail photo)

Deploy as a Render Static Site. Upload the contents of this folder to a GitHub repository, keeping the assets folder beside index.html.
Build command: leave blank
Publish directory: .

IMPORTANT BEFORE ACCEPTING REAL ORDERS:
- The cart is a visual preview, not a real checkout or order database.
- No payment gateway is connected. Do not claim online payments are active.
- Confirm the displayed ₹500 price, sizes, stock, delivery and exchange policy.
- Confirm the WhatsApp number +91 9798674867 is the correct DARVIN business contact.
